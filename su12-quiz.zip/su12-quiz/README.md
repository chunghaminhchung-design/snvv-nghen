# Lịch Sử 12 — Luyện trắc nghiệm

Web tĩnh (HTML/CSS/JS thuần, không cần build) để luyện trắc nghiệm Lịch Sử 12 theo từng chuyên đề.

## Trạng thái ngân hàng câu hỏi (đợt 1)

| Chuyên đề | Số câu |
|---|---|
| Liên hợp quốc | 20 |
| Trật tự thế giới trong và sau Chiến tranh lạnh | 20 |
| ASEAN — Hình thành và phát triển | 20 |
| **Tổng** | **60** |

Đây là 3 chuyên đề mở đầu chương trình. Ngân hàng sẽ được bổ sung dần theo từng đợt (kháng chiến chống Pháp, chống Mỹ, công cuộc Đổi mới, Hồ Chí Minh...) — nhắn lại bất cứ lúc nào để làm tiếp đợt câu hỏi mới.

## Chạy thử trên máy

Không cần cài gì cả — mở thẳng file `index.html` bằng trình duyệt là chạy được.

## Đẩy lên GitHub

```bash
cd su12-quiz
git init
git add .
git commit -m "Khởi tạo web luyện thi Lịch Sử 12"
git branch -M main
git remote add origin https://github.com/<username>/<ten-repo>.git
git push -u origin main
```

## Bật GitHub Pages (để có link web công khai)

1. Vào repo trên GitHub → **Settings** → **Pages**
2. Ở mục **Build and deployment** → **Source**, chọn **Deploy from a branch**
3. Chọn branch **main**, thư mục **/ (root)** → **Save**
4. Sau 1–2 phút, web sẽ có ở địa chỉ `https://<username>.github.io/<ten-repo>/`

## Cấu trúc thư mục

```
su12-quiz/
├── index.html          # khung trang, 3 màn hình: trang chủ / làm bài / kết quả
├── css/style.css        # toàn bộ giao diện
├── js/questions.js      # NGÂN HÀNG CÂU HỎI — sửa/thêm câu hỏi ở đây
├── js/app.js             # logic chấm điểm, chuyển màn hình, lưu lịch sử
└── README.md
```

## Cách thêm câu hỏi mới

Mở `js/questions.js`, thêm một dòng vào mảng `QUIZ_QUESTIONS`, theo đúng mẫu:

```js
{ id:"un-21", topic:"un", q:"Nội dung câu hỏi...", options:["Phương án A","Phương án B","Phương án C","Phương án D"], answer:0 },
```

- `topic` phải trùng với một `id` đã khai báo trong `QUIZ_TOPICS` (`un`, `coldwar`, `asean`), hoặc bạn khai báo chuyên đề mới trong `QUIZ_TOPICS` trước rồi mới thêm câu hỏi cho chuyên đề đó.
- `answer` là **vị trí (0–3)** của đáp án đúng trong mảng `options` — ứng dụng tự xáo trộn thứ tự đáp án mỗi lần làm bài nên không cần lo việc học "vẹt" vị trí.
- `id` nên là duy nhất, không trùng với câu đã có.

## Tính năng hiện có

- Luyện theo từng chuyên đề, hoặc trộn đề tổng hợp (30 câu ngẫu nhiên trong toàn bộ ngân hàng)
- Xáo trộn thứ tự câu hỏi và đáp án mỗi lượt làm
- Chấm điểm ngay, tô màu đáp án đúng/sai kiểu phiếu trả lời trắc nghiệm
- Biên bản kết quả: điểm số, tỉ lệ đúng theo từng chuyên đề, danh sách xem lại câu sai
- Lưu lịch sử làm bài trên trình duyệt (localStorage) — không cần server, không cần đăng nhập
